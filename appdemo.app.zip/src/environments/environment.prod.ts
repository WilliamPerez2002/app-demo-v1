export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyCaBGWBO4CegFFBcpeK0hOMEbci_YKr6es",
    authDomain: "app-wp-demo1.firebaseapp.com",
    projectId: "app-wp-demo1",
    storageBucket: "app-wp-demo1.appspot.com",
    messagingSenderId: "53061787176",
    appId: "1:53061787176:web:a0085f487bcde2e95e1f1d"
  }
};
